<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-14 23:01:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/k0253928/public_html/app/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2017-07-14 23:01:52 --> Unable to connect to the database
ERROR - 2017-07-14 23:01:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/k0253928/public_html/app/system/core/Exceptions.php:271) /home/k0253928/public_html/app/system/core/Common.php 564
