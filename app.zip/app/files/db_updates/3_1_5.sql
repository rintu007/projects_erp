UPDATE `sma_settings` SET `version` = '3.1.5' WHERE `setting_id` = 1;
