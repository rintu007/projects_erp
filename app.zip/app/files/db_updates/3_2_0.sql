UPDATE `sma_settings` SET `version` = '3.2.0' WHERE `setting_id` = 1;
