UPDATE `sma_settings` SET `version` = '3.1.3' WHERE `setting_id` = 1;
