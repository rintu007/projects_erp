UPDATE `sma_pos_settings` SET `version` = '3.1.3' WHERE `pos_id` = 1;
