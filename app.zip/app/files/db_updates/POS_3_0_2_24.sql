UPDATE `sma_pos_settings` SET `version` = '3.0.2.24' WHERE `pos_id` = 1;
