UPDATE `sma_settings` SET `version` = '3.0.2.24' WHERE `setting_id` = 1;
